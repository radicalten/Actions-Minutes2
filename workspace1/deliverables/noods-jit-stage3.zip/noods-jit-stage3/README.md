# NooDS-Wii JIT — stage 3 source bundle

**Experimental and default-off. Now includes native multiply and branch families, but is not the finished full-coverage/performance recompiler.**

Read `WORK_REPORT.md` for verified results, source-specific semantics, design boundaries and outstanding work.

## Apply ONE alternative

Back up local edits and use a feature branch.

### Clean pinned upstream checkout

Base: `1c995b48c37ebf3645646968c416958f79264137`.

```sh
git switch -c feature/ppc-jit-stage3
git apply --check /path/to/from-upstream.patch
git apply /path/to/from-upstream.patch
```

### Exact stage-2 checkout / stage-2 overlay already applied

```sh
git apply --check /path/to/from-stage2.patch
git apply /path/to/from-stage2.patch
```

### Overlay

Copy the contents of `overlay/` into the repository root, preserving relative paths and replacing the supplied files. Do not also apply a patch. Headers, generated include and integration changes are required alongside the `.cpp` files.

**Run `make clean` after applying this update.** Compiler/cache signatures, context exit fields and the differential Interpreter layout changed. The upstream Makefile does not fully track header/flag dependencies.

Recorded build logs in the patch can produce harmless trailing-whitespace warnings; normal context-check failures must still be investigated.

## Production files

In `overlay/NooDS-Wii/`:

- New this stage: **`jit_compiler_multiply.cpp`**, **`jit_compiler_branch.cpp`**.
- Updated: `jit.cpp`, `jit.h`, cache/compiler headers and sources, `jit_debug.cpp`, `jit_decode_arm.inc`, and `interpreter.cpp/.h`.
- Retained: PPC emitter, ABI trampoline, common ALU/shift compiler, settings integration and Makefile off-switch.

Standalone test mains must stay under `tests/` and `tools/`; do not add them to the emulator source directory.

## Build and enable

With the original project's devkitPPC/libogc/port-library dependencies installed:

```sh
source /home/user/wii-env.sh
make clean && make -j4
```

This produces `NooDS-Wii.dol`; rename your built copy to `boot.dol` for HBC if needed. No binary is supplied in this source-only bundle.

The runtime default is **off**. Experimental testing uses a newline-terminated ini setting:

```ini
jitEnabled=1
```

Prefer a clean `make JIT_DIFFTEST=1` build for initial console bring-up. The first detected mismatch is logged to `sd:/noods/jit_log.txt`; the reference result is retained and native execution is disabled for that session. Differential mode now checks branch refill requests as well as registers, flags and cycles.

Disable with `jitEnabled=0`, or `make clean && make NOODS_JIT=0`. Both build configurations were checked, but actual console/Dolphin runs have not been performed.

## Re-run tests

Dependencies: Python 3, host g++, PPC Linux binutils/g++, qemu-ppc-static; devkitPPC on PATH for the second oracle build.

```sh
bash tools/run_jit_asm_oracle.sh
bash tools/run_jit_flag_probe.sh
bash tools/run_jit_native_tests.sh
bash tools/run_jit_pipeline_tests.sh
JIT_ORACLE_DEVKIT=1 bash tools/run_jit_native_tests.sh
```

The isolated native oracle compiles real ALU/branch handlers but models refill normalization without memory reads. The pipeline harness uses the exact refill body with an instrumented memory backend. Neither is a complete-ROM/Core/hardware test.

## Contents and provenance

- `overlay/`: cumulative source, integration, tests, documentation and verification logs.
- `from-upstream.patch` / `from-stage2.patch`: alternative application paths.
- `WORK_REPORT.md`: current work and limitations; previous reports are archived under `overlay/docs/jit/`.
- `overlay/verification/stage3/`: current test/build/tool-version evidence.
- `package-smoke-test.log`: application checks and tests rerun from the applied package.
- `patch-bases.json`, `commits.txt`: exact source provenance.
- `SHA256SUMS`: integrity checksums excluding the checksum file itself.
- `LICENSE`: upstream GPL license; new sources use GPL-3.0-or-later identifiers.
- `setup/`: optional sandbox environment/toolchain extraction aids. The bootstrap script expects `/home/user/dkp-work/` to exist, extracts the official Docker image's opt tree after hash checks, and does not copy it into `/opt` itself. Its `latest` tag can change; the manifest records layers used here.

**Remaining:** native memory/stack/block-transfer operations, multi-instruction budgets/chaining, final invalidation/remap framework, PC/SPSR and ARM9 DSP cases, GameCube platform work, complete-ROM testing and performance measurements. One-op entry overhead may still make this slower than the interpreter.
